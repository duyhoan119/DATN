<?php

return [
    'auth' => [
        'fail'=>'Bạn không có quền thực hiện chức năng này'
    ]
];
